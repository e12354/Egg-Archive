import json

def getDefaultAvatar():
    with open(f"db\\AvatarItems.json") as f:
        items = json.load(f)
    with open(f"db\\AvatarItemsDefaultIds.json") as f:
        Default = json.load(f)
    items1 = []
    for item in items:
        if int(item["AvatarItemId"]) in Default:
            items1.append(item)
    return items1