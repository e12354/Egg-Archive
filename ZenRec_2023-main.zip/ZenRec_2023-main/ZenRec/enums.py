from enum import Enum, Flag

class RegionId(Enum):
    eu = 0
    us = 1
    asia = 2
    jp = 3
    none = 4
    au = 5
    usw = 6
    sa = 7
    cae = 8
    kr = 9
    in_ = 10
    ru = 11
    rue = 12
    femboy = 13
    trans = 14

class CELNDGJKENL(Flag):
    None_ = 0
    SheHer = 1
    HeHim = 2
    TheyThem = 4
    ZeHir = 8
    ZeZir = 16
    XeXem = 32

class NEAMMEDEKLG(Flag):
    None_ = 0
    LGBTQIA = 1
    Transgender = 2
    Bisexual = 4
    Lesbian = 8
    Pansexual = 16
    Asexual = 32
    Intersex = 64
    Genderqueer = 128
    Nonbinary = 256
    Aromantic = 512

class FKOCOFKPFDP(Enum):
    ValidForPlay = 0
    UpdateRequired = 1

class Rarity(Enum):
    None_ = -1
    Common = 0
    Uncommon = 10
    Rare = 20
    Epic = 30
    Legendary = 50

class platform(Enum):
    All = -1
    Steam = 0
    Oculus = 1
    PlayStation = 2
    Xbox = 3
    RecNet = 4
    IOS = 5
    GooglePlay = 6
    Standalone = 7
    Pico = 8

class playerReportingHile(Enum):
    Obscured = 0
    Time = 1
    Inject = 2
    GiftCount = 3
    Engine = 4
    UnknownDll = 5
    ImageSignature = 6
    AvatarHack = 7
    NetworkCertificatePublicKey = 100
    NetworkCertificateIssuer = 101
    NetworkCertificateMissing = 102
    NetworkCertificateMismatch = 103
    AutosaveChecksumMismatch = 150
    AutosaveSubRoomIdMismatch = 151
    AutosaveChecksumException = 152
    Photon_MissingHash = 200
    Photon_CorruptHash = 201
    Photon_DifferentHash = 203
    AppData_Runtime_LengthMismatch = 300
    AppData_Runtime_LastWriteTimeMismatch = 301
    AppData_Runtime_FileModified = 302
    AppData_Boot_InvalidSignature = 310
    AppData_Boot_UnableToVerifySignatures = 311
    Config_MissingHash = 320
    Config_DifferentHash = 321
    Photon_InstantiateTool = 400
    Memory_Hash_Mismatch = 500
    Driver_Invalid_Signature = 600