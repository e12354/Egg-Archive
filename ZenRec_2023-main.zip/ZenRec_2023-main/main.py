from flask import Flask, request, jsonify, send_file, redirect, make_response, url_for, render_template, Response, abort, session
from flask_cors import CORS
import json
import requests
import os
import uuid
from dotenv import load_dotenv
from ZenRec import econ_API, enums
from ZenRec import auth_API
from ZenRec import accounts_API
from ZenRec import room_API

load_dotenv()

import jwt


name = f"{__name__}.py"

app = Flask(__name__)
app.config["SECRET_KEY"] = str(uuid.uuid4())
CORS(app)


@app.errorhandler(404)
def q405(e):
    data = ""
    return data, 404

@app.errorhandler(405)
def q405(e):
    data = ""
    return data, 405

@app.errorhandler(401)
def q401(e):
    data = ""
    return data, 401

@app.errorhandler(403)
def q403(e):
    data = ""
    return data, 403

@app.errorhandler(500)
def q405(e):
    data = {"Message":"An error has occurred."}
    return jsonify(data), 500

@app.route("/", methods=["GET"])
def index():
    return abort(404)

@app.route("/ns", methods=["GET"])
def ns():
    Host = request.headers.get("Host", "null")
    baseUrl = Host
    ForwardedProto = request.headers.get("X-Forwarded-Proto", "http")
    http = ForwardedProto
    ns = {
        "RecNetStatus": None,
        "Auth": f"{http}://{baseUrl}/auth/",
        "API": f"{http}://{baseUrl}",
        "WWW": f"{http}://{baseUrl}",
        "Notifications": f"{http}://{baseUrl}/notifications/",
        "Images": f"{http}://{baseUrl}/img/",
        "CDN": f"{http}://{baseUrl}/cdn/",
        "Commerce": f"{http}://{baseUrl}/api/commerce/",
        "Matchmaking": f"{http}://{baseUrl}/api/matchmaking/",
        "Storage": f"{http}://{baseUrl}/api/storage/",
        "Chat": f"{http}://{baseUrl}/api/chat/",
        "Leaderboard": f"{http}://{baseUrl}/api/leaderboard/",
        "Accounts": f"{http}://{baseUrl}/api/accounts/",
        "Link": f"{http}://{baseUrl}/api/link/",
        "RoomComments": f"{http}://{baseUrl}/api/rooms/comments/",
        "Clubs": f"{http}://{baseUrl}/api/clubs/",
        "Rooms": f"{http}://{baseUrl}/api/rooms/",
        "PlatformNotifications": f"{http}://{baseUrl}/api/platformnotifications",
        "Moderation": f"{http}://{baseUrl}/moderation/api/",
        "DataCollection": f"{http}://{baseUrl}/api/datacollection/",
        "BugReporting": f"{http}://{baseUrl}/api/bugreporting/",
        "Discovery": f"{http}://{baseUrl}/api/discovery/",
        "PlayerSettings": f"{http}://{baseUrl}/api/playersettings/",
        "Studio": f"{http}://{baseUrl}/api/studio/",
        "GameLogs": f"{http}://{baseUrl}/api/gamelogs/",
        "Strings": f"{http}://{baseUrl}/api/strings/",
        "Econ": f"{http}://{baseUrl}",
        "StringsCDN": f"{http}://{baseUrl}/cdn/strings/"
    }
    return jsonify(ns)


@app.route("/api/gameconfigs/v1/all", methods=["GET"])
def apigameconfigsv1all():
    with open(f"db\\gameconfigs.json", encoding="utf8") as f:
        gc = json.load(f)
    return jsonify(gc)

@app.route("/api/config/v1/amplitude", methods=["GET"])
def apiconfigv1amplitude():
    data = {
        "AmplitudeKey": os.getenv("AmplitudeKey"),
        "UseRudderStack": True,
        "RudderStackKey": os.getenv("RudderStackKey"),
        "UseStatSig": True,
        "StatSigKey": os.getenv("StatSigKey"),
        "StatSigEnvironment": 0
    }
    return jsonify(data)

@app.route("/api/gamesight/event", methods=["POST"])
def apigamesightevent():
    print(request.get_data())
    data =  {"success":True}
    return jsonify(data)

@app.route("/auth/eac/challenge", methods=["GET"])
def autheacchallenge():
    #data = "AQAAAOMcuZ7EiIJeGFWCXMXbC9recfrbXWWBx1h2JthMqfQuFm/Vhnl61HSPdeyGds3lDDVmk5A4WzttJGtvKN+H4qkl+rDBEXNfQ+Iv08bxy7OyqW0lqNAZCs9c0KwqcTiOzX2MDOsAGbqUWy1g0XAzmVz9LK8xrO43Xs9zsas="
    data = "576c62bd-1555-4fa8-9da0-dbe17896957e"
    return jsonify(data)

@app.route("/api/versioncheck/v4", methods=["GET"])
def apiversioncheckv4():
    v = request.args["v"]
    iLoveMyPP = False
    if v == "20230406":
        iLoveMyPP = True
    if not iLoveMyPP:
        return jsonify({"VersionStatus":1})
    return jsonify({"VersionStatus":0})

@app.route("/api/avatar/v1/defaultunlocked", methods=["GET"])
def apiavatarv1defaultunlocked():
    return jsonify(econ_API.getDefaultAvatar())

@app.route("/auth/cachedlogin/forplatformid/<int:plat>/<platId>", methods=["GET"])
def cachedlogin(plat, platId):
    return jsonify([])

@app.route("/auth/cachedlogin/forplatformid/<Id1>/<int:Id2>", methods=["GET"])
def auth_cachedlogin_forplatformid(Id1, Id2):
    data = auth_API.cachedlogin(Id2)
    return jsonify(data)

def run():
    Port = int(os.getenv("port"))
    Ip = "0.0.0.0"
    app.run(str(Ip), int(Port), debug=False)
    #ssl_context='adhoc'