import random
import ProgramUtils


def getmyPlayer():
    with open("SaveData\\Profile\\username.txt") as f:
        username = f.read()
    with open("SaveData\\Profile\\userid.txt") as f:
        try:
            userid = int(f.read())
        except:
            userid = random.randint(10000,9999999999)
    return {
        "accountId": userid,
        "username": username,
        "displayName": username,
        "profileImage": "profileimage.png",
        "bannerImage": "profileimage.png",
        "isJunior": False,
        "platforms": 1,
        "personalPronouns": 0,
        "identityFlags": 0,
        "createdAt": ProgramUtils.getCurrentTime(),
        "isMetaPlatformBlocked": False
    }

def getcachedlogins(PlatformId: str):
    with open("SaveData\\Profile\\userid.txt") as f:
        try:
            userid = int(f.read())
        except:
            userid = random.randint(10000,9999999999)
    return [{
        "platform": 0,
        "platformId": PlatformId,
        "accountId": userid,
        "lastLoginTime": ProgramUtils.getCurrentTime(),
        "requirePassword": False,
    }]