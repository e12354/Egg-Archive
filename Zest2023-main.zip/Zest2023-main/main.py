from flask import Flask, request, jsonify, send_file, redirect, make_response, url_for, render_template, Response, abort, session
from flask_cors import CORS
from flask_sock import Sock
import json
import uuid
import random
import jwt
import requests

from RecNet import player_API
import ProgramUtils


name = f"{__name__}.py"

saveDataPath = "savedata\\"

app = Flask(__name__)
CORS(app)
sock = Sock(app)

baseUrl = "ns.rec.net"
url = f"https://{baseUrl}"

PlayerId = player_API.getmyPlayer()["accountId"]

heartbeat = {
    "playerId": PlayerId,
    "statusVisibility": 0,
    "platform": 0,
    "deviceClass": 2,
    "vrMovementMode": 0,
    "roomInstance": None,
    "lastOnline": ProgramUtils.getCurrentTime(),
    "isOnline": True,
    "appVersion": "20221209"
}


@app.errorhandler(404)
def q405(e):
    data = ""
    return data, 404

@app.errorhandler(405)
def q405(e):
    data = ""
    return data, 405

@app.errorhandler(401)
def q401(e):
    data = ""
    return data, 401

@app.errorhandler(403)
def q403(e):
    data = ""
    return data, 403

@app.errorhandler(500)
def q405(e):
    data = {"Message":"An error has occurred."}
    return jsonify(data), 500

@app.route("/", methods=["GET"])
def NameServer():
    data = {
        "Auth": f"{url}/api/auth/v1/",
        "API": f"{url}",
        "WWW": f"{url}/api/www/v1/",
        "Notifications": f"{url}/api/notifications/v1/",
        "Images": f"{url}/api/images/v1/",
        "CDN": f"{url}/api/cdn/v1/",
        "Commerce": f"{url}/api/commerce/v1/",
        "Matchmaking": f"{url}/api/matchmaking/v1/",
        "Storage": f"{url}/api/storage/v1/",
        "Chat": f"{url}/api/chat/v1/",
        "Leaderboard": f"{url}/api/leaderboard/v1/",
        "Accounts": f"{url}/api/accounts/v1/",
        "Link": f"{url}/api/link/v1/",
        "RoomComments": f"{url}/api/roomcomments/v1/",
        "Clubs": f"{url}/api/clubs/v1/",
        "Rooms": f"{url}/api/rooms/v1/",
        "PlatformNotifications": f"{url}/api/platformnotifications/v1/",
        "Moderation": f"{url}/api/moderation/v1/",
        "DataCollection": f"{url}/api/datacollection/v1/",
        "BugReporting": f"{url}/api/bugreporting/v1/",
        "Discovery": f"{url}/api/discovery/v1/",
        "PlayerSettings": f"{url}/api/playersettings/v1/",
        "Studio": f"{url}/api/studio/v1/",
        "GameLogs": f"{url}/api/gamelogs/v1/",
        "Strings": f"{url}/api/strings/v1/",
        "Econ": f"{url}",
        "StringsCDN": f"{url}/api/stringscdn/v1/"
    }
    return jsonify(data)


#* api
@app.route("/api/versioncheck/v4", methods=["GET"])
def apiversioncheckv4():
    return jsonify({"VersionStatus":0})

@app.route("/api/config/v1/amplitude", methods=["GET"])
def apiconfigv1amplitud():
    return jsonify({
        "AmplitudeKey":"e1693a1003671058b6abc356c8ba8d59",
        "UseRudderStack":True,
        "RudderStackKey":"23NiJHIgu3koaGNCZIiuYvIQNCu",
        "UseStatSig":True,
        "StatSigKey":"client-SBZkOrjD3r1Cat3f3W8K6sBd11WKlXZXIlCWj6l4Aje",
        "StatSigEnvironment":0
        }
    )

@app.route("/api/gameconfigs/v1/all", methods=["GET"])
def apigameconfigsv1all():
    with open(f"{saveDataPath}gameconfigs.json") as f:
        GC = json.load(f)
    return jsonify(GC)
    return send_file(f"{saveDataPath}gameconfigs.json")

@app.route("/api/config/v2", methods=["GET"])
def apiconfigv2():
    with open(f"{saveDataPath}config.json") as f:
        GC = json.load(f)
    return jsonify(GC)
    return send_file(f"{saveDataPath}config.json")

@app.route("/api/config/v1/backtrace", methods=["GET"])
def apiconfigv1backtrace():
    data = {"ReportBudget":0,"FilterType":0,"SampleRate":0.025,"LogLineCount":50,"CaptureNativeCrashes":1,"ANRThresholdMs":0,"MessageCount":1000,"MessageRegex":"^Cannot set the parent of the GameObject .* while its new parent|^\\>\\x2010x\\:\\x20|\\'LabelTheme\\' contains missing PaletteTheme reference on","VersionRegex":".*"}
    return jsonify(data)
    
@app.route("/api/avatar/v1/defaultunlocked", methods=["GET"])
def apiavatarv1defaultunlocked():
    with open(f"{saveDataPath}AvatarItemWardrobe.json") as f:
        GC = json.load(f)
    return jsonify(GC)
    return send_file(f"{saveDataPath}AvatarItemWardrobe.json")

@app.route("/api/customAvatarItems/v1/isCreationAllowedForAccount", methods=["GET"])
def apicustomAvatarItemsv1isCreationAllowedForAccount():
    data = {
        "success": True,
        "value": None
    }
    return jsonify(data)

@app.route("/api/objectives/v1/myprogress", methods=["GET"])
def apiobjectivesv1myprogress():
    data = {
        "Objectives": [],
        "ObjectiveGroups": []
    }
    return jsonify(data)

@app.route("/api/PlayerReporting/v1/moderationBlockDetails", methods=["GET"])
def apiPlayerReportingv1moderationBlockDetails():
    data = {
        "ReportCategory": 0,
        "IsBan": False,
        "IsVoiceModAutoban": False,
        "IsWarning": False,
        "Duration": 0,
        "GameSessionId": 0,
        "Message": ""
    }
    return jsonify(data)

@app.route("/api/avatar/v2", methods=["GET"])
def apiavatarv2():
    with open("savedata\\avatar.json") as f:
        avatar = json.load(f)
    data = avatar
    return jsonify(data)

@app.route("/api/avatar/v4/items", methods=["GET"])
def apiavatarv4items():
    with open(f"{saveDataPath}AvatarItemWardrobe.json") as f:
        GC = json.load(f)
    return jsonify(GC)
    return send_file(f"{saveDataPath}AvatarItemWardrobe.json")

@app.route("/api/avatar/v1/defaultbaseavataritems", methods=["GET"])
def apiavatarv1defaultbaseavataritems():
    data = []
    return jsonify(data)

@app.route("/econ/customAvatarItems/v1/owned", methods=["GET"])
def econcustomAvatarItemsv1owned():
    data = {"Results": [], "TotalResults": 0}
    return jsonify(data)

@app.route("/api/relationships/v2/get", methods=["GET"])
def apirelationshipsv2get():
    return jsonify([])

@app.route("/api/customAvatarItems/v1/bulk", methods=["POST"])
def apicustomAvatarItemsv1bulk():
    data = []
    return jsonify(data)

@app.route("/api/playerReputation/v2/bulk", methods=["GET"])
def apiplayerReputationv2bulk():
    data = [
        {
            "AccountId": player_API.getmyPlayer()["accountId"]
        }
    ]
    return jsonify(data)

@app.route("/api/players/v2/progression/bulk", methods=["GET"])
def apiplayersv2progressionbulk():
    with open("SaveData\\Profile\\level.txt") as f:
        try:
            level = int(f.read())
        except:
            level = 0
    data = [
        {
            "PlayerId": player_API.getmyPlayer()["accountId"],
            "Level": level,
            "XP": 0
        }
    ]
    return jsonify(data)

@app.route("/api/quickPlay/v1/getandclear", methods=["GET"])
def apiquickPlayv1getandclear():
    data = None
    return jsonify(data)

#* matchmaking
@app.route("/api/matchmaking/v1/player/login", methods=["POST"])
def apimatchmakingv1playerlogin():
    data = "OK"
    return jsonify(data)

@app.route("/api/matchmaking/v1/player/exclusivelogin", methods=["POST"])
def apimatchmakingv1playerexclusivelogin():
    return "OK", 200
    TakeOverExclusiveSession = request.form["TakeOverExclusiveSession"]
    if TakeOverExclusiveSession == "True":
        data = "OK"
        return jsonify(data), 200
    data = "NO"
    return jsonify(data), 400

@app.route("/api/matchmaking/v1/player/heartbeat", methods=["POST"])
def apimatchmakingv1playerheartbeat():
    data = heartbeat
    return jsonify(data)


#* notifications
@app.route("/api/notifications/v1/hub/v1/negotiate", methods=["POST"])
def apinotificationsv1hubv1negotiate():
    data = {
        "url": f"{url}/api/notifications/v1/"
    }
    return jsonify(data)

@app.route("/api/notifications/v1/negotiate", methods=["POST"])
def apinotificationsv1negotiate():
    data = {
        "negotiateVersion": 0,
        "connectionId": "OWO:3",
        "availableTransports": [
            {
                "transport": "WebSockets",
                "transferFormats": [
                    "Text",
                    "Binary"
                ]
            }
        ]
    }
    return jsonify(data)

@sock.route("/api/notifications/v1/")
def apinotificationsv1(ws):
    while True:
        data = ws.receive()
        print("received data: " + str(data))
        ws.send(data)

#* auth
@app.route("/api/auth/v1/cachedlogin/forplatformid/0/<PlatformId>", methods=["GET"])
def apiauthv1cachedloginforplatformid0(PlatformId):
    data = player_API.getcachedlogins(PlatformId)
    return jsonify(data)

@app.route("/api/auth/v1/eac/challenge", methods=["GET"])
def apiauthv1eacchallenge():
    data = "AQAAAHsg7mW5FQEE9HVl9EKMWXrqDzQxUCdgV/IPuQfbRgTx+cGnQqhhAgv1RvpihEC77gQ29JdoGFn2806Q+QPEj7nYg9C8pynbaiSVO8rKLJPvROsHuSXVJpQMv3TD8KyK3Y+n5bb86vAb5kRdZGD//uC8HY+D9jJLlEfTUlU="
    return jsonify(data)

@app.route("/api/auth/v1/connect/token", methods=["POST"])
def apiauthv1connecttoken():
    with open("SaveData\\Profile\\userid.txt") as f:
        try:
            userid = int(f.read())
        except:
            userid = random.randint(10000,9999999999)
    tokenRAW = {
        "iss": f"{url}/api/auth/v1/",
        "client_id": "recnet",
        "role": [
            "moderator",
            "screenshare",
            "keepsake",
            "developer"
        ],
        "sub": userid
    }
    key = ""
    token = jwt.encode(tokenRAW, key)
    data = {
        "access_token": token,
        "refresh_token": ":3",
        "key": key
    }
    return jsonify(data)


#* accounts
@app.route("/api/accounts/v1/account/bulk", methods=["GET"])
def apiaccountsv1accountbulk():
    data = [player_API.getmyPlayer()]
    return jsonify(data)

@app.route("/api/accounts/v1/account/me", methods=["GET"])
def apiaccountsv1account():
    data = player_API.getmyPlayer()
    return jsonify(data)

@app.route("/api/playersettings/v1/playersettings", methods=["GET", "PUT"])
def apiplayersettingsv1playersettings():
    data = []
    if request.method == "PUT":
        data = "OK"
        return jsonify(data)
    return jsonify(data)

#* cdn
@app.route("/api/cdn/v1/config/LoadingScreenTipData", methods=["GET"])
def apicdnv1configLoadingScreenTipData():
    return jsonify([])
    data = requests.request("GET", "https://cdn.rec.net/config/LoadingScreenTipData", verify=False)
    return jsonify(data.json())

#* chat
@app.route("/api/chat/v1/thread", methods=["GET"])
def apichatv1thread():
    data = []
    return jsonify(data)

def run():
    Port = 443
    Ip = "0.0.0.0"
    app.run(str(Ip), int(Port), ssl_context="adhoc")

run()