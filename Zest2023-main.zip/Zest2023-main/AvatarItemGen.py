temp = {'AvatarItemDesc': '97253092-90ba-4ff2-b137-6324ab244d11,f335220c-f717-4d00-bed2-0e190ff65972', 'AvatarItemType': 0, 'PlatformMask': -1, 'FriendlyName': 'Dragon Lunar New Year Sweater', 'Tooltip': '', 'Rarity': -1, 'TagList': None, 'AvatarItemId': 6460, 'IsBaseAvatarItem': False, 'CreatedAt': '2024-02-08T23:18:49.287Z', 'ThumbnailImage': 'cdnz7aqx6sfcbsgge2d2pr2ai.jpg'}
import json
import ProgramUtils

with open("AvatarItemWardrobeRuntimeConfig.json") as f:
    sk = json.load(f)
allPossibleCombinations = sk["allPossibleCombinations"]
num = 1

avlist = []

for allPossibleCombination in allPossibleCombinations:
    _avatarItemData = allPossibleCombination["_avatarItemData"]
    _avatarItemVisualData = allPossibleCombination["_avatarItemVisualData"]
    FriendlyNameSkinAssetName = str(_avatarItemData["Name"])
    FriendlyNameSkinAssetName = FriendlyNameSkinAssetName.replace("(", "")
    FriendlyNameSkinAssetName = FriendlyNameSkinAssetName.replace(")", "")
    AvatarItemDesc = f"{_avatarItemVisualData["prefabGuid"]},{_avatarItemVisualData["combinationGuid"]}"
    FriendlyName = f"{FriendlyNameSkinAssetName}: {AvatarItemDesc}"
    newAV = {
        'AvatarItemDesc': AvatarItemDesc, 
        'AvatarItemType': 0, 
        'PlatformMask': -1, 
        'FriendlyName': FriendlyName, 
        'Tooltip': '', 
        'Rarity': -1, 
        'TagList': None, 
        'AvatarItemId': num, 
        'IsBaseAvatarItem': False, 
        'CreatedAt': ProgramUtils.getCurrentTime(), 
        'ThumbnailImage': 'cdnz7aqx6sfcbsgge2d2pr2ai.jpg'
    }
    num += 1
    avlist.append(newAV)

with open("AvatarItemWardrobe.json", "w") as f:
    json.dump(avlist, f, indent=2)

print(avlist)

