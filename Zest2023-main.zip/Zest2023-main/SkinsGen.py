temp = {'PrefabName': '[ShareCamera]', 'ModificationGuid': 'f5f52249-0c02-43e9-a31b-799d230098a0', 'Favorited': True, 'PlatformMask': -1, 'FriendlyName': 'Cryptid Camera Skin', 'Tooltip': '', 'Rarity': 50, 'ThumbnailImageName': '7yjasveeo5kctct8dhredhzlb.png'}
import json

with open("skins.json") as f:
    sk = json.load(f)
toolSkinMaps = sk["toolSkinMaps"]

skinlist = []

for toolSkinMap in toolSkinMaps:
    equipment = toolSkinMap["equipment"]
    skins = toolSkinMap["skins"]
    for skin in skins:
        FriendlyNameSkinAssetName = str(skin["skinAssetName"])
        FriendlyNameSkinAssetName = FriendlyNameSkinAssetName.replace("_", " ")
        FriendlyName = f"{FriendlyNameSkinAssetName}"
        print(FriendlyName)
        newskin1 = {
            'PrefabName': equipment["prefabName"], 
            'ModificationGuid': skin["skinGuid"], 
            'Favorited': False, 
            'PlatformMask': -1, 
            'FriendlyName': FriendlyName, 
            'Tooltip': '', 
            'Rarity': 50, 
            'ThumbnailImageName': 'cdnz7aqx6sfcbsgge2d2pr2ai.jpg'
        }
        skinlist.append(newskin1)
        #print(f"{equipment["prefabName"]}  {skin}")

with open("equipment.json", "w") as f:
    json.dump(skinlist, f, indent=2)

print(skinlist)