from flask import Flask, request, jsonify, send_file, redirect, make_response, url_for, render_template, Response, abort, session
from flask_cors import CORS
import json
import requests
import os
import uuid

name = f"{__name__}.py"

app = Flask(__name__)
app.config["SECRET_KEY"] = str(uuid.uuid4())
CORS(app)

dbPath = "C:\\ZestRec\\db\\"#* Example "C:\\ZestRec\\db\\"
cdnPath = ""#* Example "C:\\ZestRec\\cdn\\"
imgPath = ""#* Example "C:\\ZestRec\\img\\"


@app.errorhandler(404)
def q405(e):
    data = ""
    return data, 404

@app.errorhandler(405)
def q405(e):
    data = ""
    return data, 405

@app.errorhandler(401)
def q401(e):
    data = ""
    return data, 401

@app.errorhandler(403)
def q403(e):
    data = ""
    return data, 403

@app.errorhandler(500)
def q405(e):
    data = {"Message":"An error has occurred."}
    return jsonify(data), 500

@app.route("/", methods=["GET"])
def index():
    return abort(404)

@app.route("/api/versioncheck/v4", methods=["GET"])
def apiversioncheckv4():
    return jsonify({"VersionStatus":0})

@app.route("/api/config/v1/amplitude", methods=["GET"])
def apiconfigv1amplitud():
    return jsonify({
        "AmplitudeKey":"e1693a1003671058b6abc356c8ba8d59",
        "UseRudderStack":True,
        "RudderStackKey":"23NiJHIgu3koaGNCZIiuYvIQNCu",
        "UseStatSig":True,
        "StatSigKey":"client-SBZkOrjD3r1Cat3f3W8K6sBd11WKlXZXIlCWj6l4Aje",
        "StatSigEnvironment":0
        }
    )

@app.route("/api/gameconfigs/v1/all", methods=["GET"])
def apigameconfigsv1all():
    with open(f"{dbPath}api\\gameconfigs.json") as f:
        return jsonify(json.load(f))
    
@app.route("/api/avatar/v1/defaultunlocked", methods=["GET"])
def apiavatarv1defaultunlocked():
    return jsonify([])

def run():
    Port = 7010
    Ip = "0.0.0.0"
    app.run(str(Ip), int(Port))
    #ssl_context='adhoc'

run()