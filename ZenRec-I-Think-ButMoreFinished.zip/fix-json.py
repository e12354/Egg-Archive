import json

#with open("json\\GC.json") as f:
#    data = json.load(f)
#
#with open("json\\GC.json", "w") as f:
#    json.dump(data, f, indent=2)

with open("json\\Room\\Rooms.json") as f:
    rooms111 = json.load(f)
#

rooms = []
for room in rooms111:
    newRoom = {
        "Accessibility": room["Accessibility"],
        "CloningAllowed": room["CloningAllowed"],
        "CreatedAt": room["CreatedAt"],
        "CreatorAccountId": room["CreatorAccountId"],
        "CustomWarning": room["CustomWarning"],
        "DataBlob": room["DataBlob"],
        "Description": room["Description"],
        "DisableMicAutoMute": room["DisableMicAutoMute"],
        "DisableRoomComments": room["DisableRoomComments"],
        "EncryptVoiceChat": room["EncryptVoiceChat"],
        "ImageName": room["ImageName"],
        "IsDorm": room["IsDorm"],
        "IsRRO": room["IsRRO"],
        "LoadScreenLocked": room["LoadScreenLocked"],
        "LoadScreens": room["LoadScreens"],
        "MaxPlayerCalculationMode": room["MaxPlayerCalculationMode"],
        "MaxPlayers": room["MaxPlayers"],
        "MinLevel": room["MinLevel"],
        "Name": room["Name"],
        "PromoExternalContent": room["PromoExternalContent"],
        "PromoImages": room["PromoImages"],
        "Roles": room["Roles"],
        "RoomId": room["RoomId"],
        "State": room["State"],
        "Stats": room["Stats"],
        "SupportsJuniors": room["SupportsJuniors"],
        "SupportsLevelVoting": room["SupportsLevelVoting"],
        "SupportsMobile": room["SupportsMobile"],
        "SupportsQuest2": room["SupportsQuest2"],
        "SupportsScreens": room["SupportsScreens"],
        "SupportsTeleportVR": room["SupportsTeleportVR"],
        "SupportsVRLow": room["SupportsVRLow"],
        "SupportsWalkVR": room["SupportsWalkVR"],
        "Tags": room["Tags"],
        "Version": 0,
        "WarningMask": room["WarningMask"]
    }
    print(newRoom)
    rooms.append(newRoom)

with open("json\\Room\\RoomsV2.json", "w") as f:
    json.dump(rooms, f, indent=2)