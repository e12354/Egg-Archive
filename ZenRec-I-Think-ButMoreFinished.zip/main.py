from VisualRec import Server, WebServer, accounts_API

#accounts_API.create("", "76561199164213831", "")

#accounts_API.create("", "76561199157823733", "")

accounts_API.create("", "76561199244473837", "")

import threading

threading.Thread(target=WebServer.run).start()
Server.run()

CheerCategory=9000