import json

def run(Json, accountId):
    Json = Json
    key = Json["Key"]
    Value = Json["Value"]
    with open("json\\settings.json", "r") as f:
      PlayerSettings = json.load(f)
    for x in PlayerSettings:
      if x["id"] == accountId:
        for y in x["settingsData"]:
          if y["Key"] == key:
            y["Value"] = Value
            with open("json\\settings.json", "w") as f:
              json.dump(PlayerSettings, f, indent=2)
            return PlayerSettings
        x["settingsData"].append({"Key":key,"Value":Value})
        with open("json\\settings.json", "w") as f:
          json.dump(PlayerSettings, f, indent=2)
        return PlayerSettings
      
with open("json\\players.json") as f:
  p = json.load(f)

for pp in p:
   run({"Key": "USE_NEW_HOME_SCREEN", "Value": "True"}, pp["accountId"])