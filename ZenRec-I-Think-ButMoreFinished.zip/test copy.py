from VisualRec import ProgramUtils, auth_API

print(auth_API.hashString("test12345678"))