from flask import Flask, request, jsonify, send_file, redirect, make_response, url_for, render_template, Response, abort, session
from flask_cors import CORS
import json
import requests
import os
import uuid

name = f"{__name__}.py"

app = Flask(__name__)
app.config["SECRET_KEY"] = str(uuid.uuid4())
CORS(app)

dbPath = "C:\\ZestRec\\db\\"#* Example "C:\\ZestRec\\db\\"
cdnPath = ""#* Example "C:\\ZestRec\\cdn\\"
imgPath = ""#* Example "C:\\ZestRec\\img\\"


@app.errorhandler(404)
def q405(e):
    data = ""
    return data, 404

@app.errorhandler(405)
def q405(e):
    data = ""
    return data, 405

@app.errorhandler(401)
def q401(e):
    data = ""
    return data, 401

@app.errorhandler(403)
def q403(e):
    data = ""
    return data, 403

@app.errorhandler(500)
def q405(e):
    data = {"Message":"An error has occurred."}
    return jsonify(data), 500

@app.route("/", methods=["GET"])
def index():
    return abort(404)
    
@app.route("/cachedlogin/forplatformid/<int:Platform>/<PlatformId>", methods=["GET"])
def cachedloginforplatformid(Platform, PlatformId):
    if Platform != 0:
        return abort(404)
    return jsonify([])
    with open(f"{dbPath}auth\\cachedlogins.json") as f:
        cachedlogins = json.load(f)
    return jsonify([])

@app.route("/eac/challenge", methods=["GET"])
def eacchallenge():
    return jsonify("AQAAAHsg7mW5FQEE9HVl9EKMWXrqDzQxUCdgV/IPuQfbRgTx+cGnQqhhAgv1RvpihEC77gQ29JdoGFn2806Q+QPEj7nYg9C8pynbaiSVO8rKLJPvROsHuSXVJpQMv3TD8KyK3Y+n5bb86vAb5kRdZGD//uC8HY+D9jJLlEfTUlU=")

def run():
    Port = 7013
    Ip = "0.0.0.0"
    app.run(str(Ip), int(Port))
    #ssl_context='adhoc'

run()