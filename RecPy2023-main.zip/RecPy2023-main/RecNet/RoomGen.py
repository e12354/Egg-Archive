import json
import ProgramUtils

name = f"{__name__}.py"

def gen(readFile: str, writeFile: str):
    pass