from RecNet import ConsumableGen

ConsumableGen.gen("helloooo.json")